import { Image } from 'expo-image';
import { Platform, StyleSheet } from 'react-native';

import { Collapsible } from '@/components/ui/collapsible';
import { ExternalLink } from '@/components/external-link';
import ParallaxScrollView from '@/components/parallax-scroll-view';
import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Link } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { IconSymbol } from '@/components/ui/icon-symbol';
import { Fonts } from '@/constants/theme';

export default function TabTwoScreen() {
  return (
   <ParallaxScrollView
      headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}
      headerImage={
  <Image
    source={require('@/assets/images/img_usuario.png')}
    style={styles.headerImage}
  />
}>
      <ThemedView style={styles.titleContainer}>
        <ThemedText
          type="title"
          style={{
            fontFamily: Fonts.rounded,
          color: "#00FFFF"
          }}>    
Usuario  
        </ThemedText>
      </ThemedView>

 <ThemedView style={styles.contenedorPrincipalVistas}>

         <ThemedView style={styles.stepContainer}>
        <Link href="/modalReserve">
          <Link.Trigger>
            <ThemedText type="title" style = {{color: "#00FFFF", fontWeight: "300", fontSize: 20 }}>Información de perfil </ThemedText>
            <Ionicons name="chevron-forward" size={24} color="#00FFFF"/>
          </Link.Trigger>
          <Link.Preview />
          <Link.Menu>
            <Link.MenuAction title="Action" icon="cube" onPress={() => alert('Action pressed')} />
            <Link.MenuAction
              title="Share"
              icon="square.and.arrow.up"
              onPress={() => alert('Share pressed')}
            />
            <Link.Menu title="More" icon="ellipsis">
              <Link.MenuAction
                title="Delete"
                icon="trash"
                destructive
                onPress={() => alert('Delete pressed')}
              />
            </Link.Menu>
          </Link.Menu>
        </Link>
      </ThemedView>
  

         <ThemedView style={styles.stepContainer}>
        <Link href="/modalReserve">
          <Link.Trigger>
            <ThemedText type="title" style = {{color: "#00FFFF", fontWeight: "300", fontSize: 20 }}>Editar perfil </ThemedText>
            <Ionicons name="chevron-forward" size={24} color="#00FFFF"/>
          </Link.Trigger>
          <Link.Preview />
          <Link.Menu>
            <Link.MenuAction title="Action" icon="cube" onPress={() => alert('Action pressed')} />
            <Link.MenuAction
              title="Share"
              icon="square.and.arrow.up"
              onPress={() => alert('Share pressed')}
            />
            <Link.Menu title="More" icon="ellipsis">
              <Link.MenuAction
                title="Delete"
                icon="trash"
                destructive
                onPress={() => alert('Delete pressed')}
              />
            </Link.Menu>
          </Link.Menu>
        </Link>
      </ThemedView>
     
         <ThemedView style={styles.stepContainer}>
        <Link href="/modalReserve">
          <Link.Trigger>
            <ThemedText type="title" style = {{color: "#00FFFF", fontWeight: "300", fontSize: 20 }}>Sesión </ThemedText>
            <Ionicons name="chevron-forward" size={24} color="#00FFFF"/>
          </Link.Trigger>
          <Link.Preview />
          <Link.Menu>
            <Link.MenuAction title="Action" icon="cube" onPress={() => alert('Action pressed')} />
            <Link.MenuAction
              title="Share"
              icon="square.and.arrow.up"
              onPress={() => alert('Share pressed')}
            />
            <Link.Menu title="More" icon="ellipsis">
              <Link.MenuAction
                title="Delete"
                icon="trash"
                destructive
                onPress={() => alert('Delete pressed')}
              />
            </Link.Menu>
          </Link.Menu>
        </Link>
      </ThemedView>
      </ThemedView>
    </ParallaxScrollView>
  );
}


const styles = StyleSheet.create({

 contenedorPrincipalVistas: {
    top: 50,
    padding: 30,
    bottom: 10,
    alignItems: 'flex-start',
    gap: 10,
 },

  headerImage: {
    top: 85,
     width: 120,
      height: 120,
      borderRadius: 60,
      alignSelf: "center", 
  },
  titleContainer: {
     top: 15,
    bottom: 10,
    alignItems: 'center',
    gap: 10,
     color: "#00FFFF",
  },
    stepContainer: {
    padding: 10,
    bottom: 10,
    gap: 8,
    marginBottom: 20,
  },
});
