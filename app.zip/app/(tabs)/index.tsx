import { Image } from 'expo-image';
import { Platform, Pressable, StyleSheet } from 'react-native';
import { HelloWave } from '@/components/hello-wave';
import ParallaxScrollView from '@/components/parallax-scroll-view';
import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { Link } from 'expo-router';
import { BottomTabBar } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import { View } from 'react-native';


export default function HomeScreen() {
  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: '#A1CEDC', dark: '#1D3D47' }}
      headerImage={
        <Image
          source={require('@/assets/images/lockers_head.jpg')}
          style={styles.lockerHead}
        />
      }>
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title" style = {{color: "#00FFFF"}}>¡Bienvenido!</ThemedText>
        <ThemedText type="title" style = {{color: "#00FFFF"}}>¿Qué deseas hacer?</ThemedText>
      </ThemedView>

  <ThemedView style={styles.contenedorPrincipalVistas}>

{/* Aquí inicia el codigo de las reservas */}

            <ThemedView style={styles.stepContainer}>
        <Link href="/modalReserve">
          <Link.Trigger>
            <ThemedText type="title" style = {{color: "#00FFFF", fontWeight: "300", fontSize: 20 }}>Presiona aquí para reservar </ThemedText>
            <Ionicons name="chevron-forward" size={24} color="#00FFFF"/>
          </Link.Trigger>
          <Link.Preview />
          <Link.Menu>
            <Link.MenuAction title="Action" icon="cube" onPress={() => alert('Action pressed')} />
            <Link.MenuAction
              title="Share"
              icon="square.and.arrow.up"
              onPress={() => alert('Share pressed')}
            />
            <Link.Menu title="More" icon="ellipsis">
              <Link.MenuAction
                title="Delete"
                icon="trash"
                destructive
                onPress={() => alert('Delete pressed')}
              />
            </Link.Menu>
          </Link.Menu>
        </Link>
      </ThemedView>

{/* Aquí inicia el codigo de la verificación de reservas */}

      <ThemedView style={styles.stepContainer}>
        <Link href="/modalVerify">
          <Link.Trigger>
            <ThemedText type="title" style={{color: "#00FFFF",  fontWeight: "300", fontSize: 20}}>Presiona aquí verificar tu reserva </ThemedText>
            <Ionicons name="chevron-forward" size={24} color="#00FFFF" />
            <ThemedText>  </ThemedText>
          </Link.Trigger>
          <Link.Preview />
          <Link.Menu>
            <Link.MenuAction title="Action" icon="cube" onPress={() => alert('Action pressed')} />
            <Link.MenuAction
              title="Share"
              icon="square.and.arrow.up"
              onPress={() => alert('Share pressed')}
            />
            <Link.Menu title="More" icon="ellipsis">
              <Link.MenuAction
                title="Delete"
                icon="trash"
                destructive
                onPress={() => alert('Delete pressed')}
              />
            </Link.Menu>
          </Link.Menu>
        </Link>

      </ThemedView>


{/* Aquí inicia el codigo de las multas */}


           <ThemedView style={styles.stepContainer}>

        <Link href="/modalTax">
          <Link.Trigger>
        
            <ThemedText type="title" style = {{color: "#00FFFF",  fontWeight: "300", fontSize: 20}}>Presiona aquí para ver multas </ThemedText>
            <Ionicons name="chevron-forward" size={24} color="#00FFFF" />
          
          </Link.Trigger>
          <Link.Preview />
          <Link.Menu>
            <Link.MenuAction title="Action" icon="cube" onPress={() => alert('Action pressed')} />
            <Link.MenuAction
              title="Share"
              icon="square.and.arrow.up"
              onPress={() => alert('Share pressed')}
            />
            <Link.Menu title="More" icon="ellipsis">
              <Link.MenuAction
                title="Delete"
                icon="trash"
                destructive
                onPress={() => alert('Delete pressed')}
              />
            </Link.Menu>
          </Link.Menu>
        </Link>

      </ThemedView>
 {/* Aquí termina el codigo de vistas */}     
      </ThemedView>



    </ParallaxScrollView>
  );
}


const styles = StyleSheet.create({


 contenedorPrincipalVistas: {
   top: 50,
    bottom: 10,
    alignItems: 'flex-start',
    gap: 10,
 },
  titleContainer: {
    top: 15,
    bottom: 10,
    alignItems: 'center',
    gap: 10,
  },
  stepContainer: {
    padding: 10,
    bottom: 10,
    gap: 8,
    marginBottom: 20,
  },
  lockerHead: {
  height: 300,
  width: 390,
  bottom: 0,
  top: 0,
  position: 'absolute',
  alignSelf: 'center', 
  },
});