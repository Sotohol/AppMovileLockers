import { DarkTheme, DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import 'react-native-reanimated';
import React, { useState } from 'react';

import { useColorScheme } from '@/hooks/use-color-scheme';

export default function RootLayout() {
  const colorScheme = useColorScheme();

  // Estado simple para saber si el usuario está logueado
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <ThemeProvider value={colorScheme === 'dark' ? DarkTheme : DefaultTheme}>
      <Stack screenOptions={{ headerShown: false }}>
        {/* Si no está logueado, manda al login */}
        {!isLoggedIn ? (
          <Stack.Screen
            name="loginScreen"
            options={{ headerShown: false }}
            // Eliminamos initialParams, ya que no se utiliza para la navegación
            // initialParams={{ setIsLoggedIn }} 
          />
        ) : (
          <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
        )}

        {/* Modal opcional (Asegúrate de incluir todas tus rutas modales aquí) */}
        <Stack.Screen
          name="modal"
          options={{ presentation: 'modal', title: 'Modal' }}
        />
        {/* Asegúrate de incluir todas tus rutas modales aquí para que Expo Router las conozca */}
        <Stack.Screen name="usuarioModalCuenta" options={{ presentation: 'modal' }} />
        <Stack.Screen name="usuarioModalEditar" options={{ presentation: 'modal' }} />
        <Stack.Screen name="usuarioModalSesion" options={{ presentation: 'modal' }} />
        <Stack.Screen name="modalTax" options={{ presentation: 'modal' }} />
        <Stack.Screen name="modalVerify" options={{ presentation: 'modal' }} />
        <Stack.Screen name="modalReserve" options={{ presentation: 'modal' }} />

      </Stack>
      <StatusBar style="auto" />
    </ThemeProvider>
  );
}